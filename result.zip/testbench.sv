module uart_top_tb;
  
  reg clk,rst;
  reg [7:0] data_in;
  reg wrt_en;
  

  wire rdy;
  reg rdy_clr;
  wire [7:0] dout;
  
  wire busy;
  
  uart_top dut(rst,data_in,wrt_en,clk,rdy_clr,rdy,busy,dout);
  
  initial begin
    $dumpfile("uart_top.vcd");
    $dumpvars(0,uart_top_tb);
    {clk,rst,data_in,rdy_clr}=0;
  end
  
  always #5 clk = ~clk;
  
  task send_byte(input [7:0] din);
    begin
    
      @(negedge clk);
      data_in = din;
      wrt_en = 1'b1;
      @(negedge clk);
      wrt_en = 0;
      
    end
  endtask
  
  task clear_ready;
    begin
      @(negedge clk)
      rdy_clr = 1'b1;
      @(negedge clk)
      rdy_clr = 0;
    end
  endtask
  
  initial begin
    
    @(negedge clk)
    rst = 1'b1;
    
    @(negedge clk)
    rst = 0;
    
        send_byte(8'h41);
    	//wait(!busy);
  		//wait(rdy);
  		$display("Recieved data is %h", dout);
  		clear_ready;
    
    send_byte(8'h55);
    //wait(!busy);
    //wait(rdy);
    $display("Recieved data is %h", dout);
    clear_ready;
    
    #400 $finish;
    
  end
endmodule